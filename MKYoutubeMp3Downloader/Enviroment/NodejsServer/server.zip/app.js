
  var http = require('http');
  const readline = require('readline');
  const path = require('path');
  const fs   = require('fs');
  const ytdl = require('ytdl-core');

  var bodyParser = require("body-parser");

  var app = require('express')();
  app.use(bodyParser.urlencoded({ extended: false }));
  app.use(bodyParser.json());

 let server = app.listen(3000);
  console.log("Connected server");

  /* GET SERVER INFO */

  app.get("/info", function(request, response) {
    response.send(JSON.stringify({
      "server" : Number(process.version.match(/^v(\d+\.\d+)/)[1]),
      "App name" : "Youtube Video Downloader",
      "Author" : "Madrit Kacabumi",
      "Email" : "dev.madrit.kacabumi@gmail.com",
      "description" : "This software is intended for educational purposes. This is against Youtube polices or.. whatever laws and stuff. Use it at your own responsability."
    }));
  });

  /* GET YOUTUBE INFO */
  app.post('/youtubeVideoInfo', function (request, response) {
    console.log(request.body.youtubeUrl);
    let youtubeUrl = request.body.youtubeUrl

  if(youtubeUrl == null || !ytdl.validateURL(youtubeUrl)) {

    response.status(400).send(JSON.stringify({"error" : true, "errorMessage" : "Invalid Youtube Url"}));
    return;
  }
    
  ytdl.getInfo(youtubeUrl, (err, info) => {

    if(err){
        response.status(400).send(JSON.stringify({"error" : true, "errorMessage" : err.message}));
        return;
    }

    // thumbnailob
    var thumbnailObj = null;
    let thumbnailArray = info.player_response.videoDetails.thumbnail.thumbnails;
    if(thumbnailArray != null && Array.isArray(thumbnailArray) && thumbnailArray.length > 0) {
      thumbnailObj = thumbnailArray[thumbnailArray.length - 1].url;
    }

    //length
    var length = 0.0 // s
    let formatsArray = info.player_response.streamingData.formats;

    if(formatsArray != null && Array.isArray(formatsArray) && formatsArray.length > 0) {
        let approxDurationMs = formatsArray[formatsArray.length - 1].approxDurationMs; // ms
        if(approxDurationMs != null) {
          length = approxDurationMs / 1000;
        }
    }


    let objectInfo = {
      "title" : info.player_response.videoDetails.title,
      "thumbnail" : thumbnailObj,
      "length" : length
    }

    const json = JSON.stringify(objectInfo, null, 4)
      .replace(/(ip(?:=|%3D|\/))((?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|[0-9a-f]{1,4}(?:(?::|%3A)[0-9a-f]{1,4}){7})/ig, '$10.0.0.0');
    response.setHeader('Content-Type', 'application/json');
    response.send(json);
  });
  })

  /* GET YOUTUBE VIDEO */
  app.post('/downloadYoutubeVideo', function (request, response) {

    console.log(request.body.youtubeUrl);
    let youtubeUrl = request.body.youtubeUrl
    let videoFileName = request.body.videoFileName;

    downloadYoutubeVideo(youtubeUrl, response, videoFileName);
  });

  /* 
   * Download video and store it to a file 
   * Create a unique file json writting the progress and operations
   */

   /**
    * Download video and saves it to a video file 
    * Create a unique file json writting the progress and operations
    *
    * @param {string} youtubeUrl - The url video to download.
    * @param {response} response - The response the client is waiting.
    * @param {string} videoFileName - The name of the video file.
    */
  function downloadYoutubeVideo(youtubeUrl, response, videoFileName){

    let timeStamp = escape(new Date().toISOString());
    var filepath = path.resolve(__dirname, timeStamp + '_actions.json');
    
    let responseJson = JSON.stringify({
      "success" : true,
      "actions_file" : filepath,
    });

  if(youtubeUrl == null || !ytdl.validateURL(youtubeUrl)) {

    let startObjectAction = JSON.stringify({
      "action" : "ERROR_VIDEO_DOWNLOAD",
      "message" : "Invalid Youtube Url"
    });

   fs.writeFile(filepath, startObjectAction, err => {
       if (err) throw err;
        response.send(responseJson);
    });
    return;
  }

  let fileName = videoFileName != null ? (videoFileName + "_" + timeStamp + ".mp4") : "downloadedVideo_" + timeStamp +".mp4";
  var mainOutput = path.resolve(__dirname, encodeURI(fileName));

  let startObjectAction = JSON.stringify({
    "action" : "START_VIDEO_DOWNLOAD",
    "message" : ""
  });

  let starttime;

  ytdl(youtubeUrl, {
    quality : "highest",
    filter : "audio"
  })
  .once('response', () => {
    starttime = Date.now();
  })
  .on('error', error => {

    let startObjectAction = JSON.stringify({
      "action" : "ERROR_VIDEO_DOWNLOAD",
      "message" : error.message
    });

   fs.writeFile(filepath, startObjectAction, err => {
       if (err) throw err;
    });

  })
  .on('progress', (chunkLength, downloaded, total) => {

      const percent = downloaded / total;
      const downloadedMinutes = (Date.now() - starttime) / 1000 / 60;
      let progressObjectAction = JSON.stringify({
        "action" : "PROGRESS_VIDEO_DOWNLOAD",
        "message" : "",
        "percent" : (percent * 100).toFixed(2),
        "downloaded" : (downloaded / 1024 / 1024).toFixed(2),
        "totalSize" : (total / 1024 / 1024).toFixed(2),
        "sizeLabel" : "MB",
        "estimatedTimeLeft" : (downloadedMinutes / percent - downloadedMinutes).toFixed(2)
      })

      // clean the actions file
    fs.truncate(filepath, 0, function(){})

      // write the action
    fs.writeFile(filepath, progressObjectAction, err => {
        if (err) throw err;
      });

    })
    .on("end", () => {
        let endObjectAction = JSON.stringify({
          "action" : "END_VIDEO_DOWNLOAD",
          "message" : "Video downloaded success Fully",
          "video_file_url" : mainOutput
        })
        // clean the actions file
      fs.truncate(filepath, 0, function(){})
        // write the action
      fs.writeFile(filepath, endObjectAction, err => {
        if (err) throw err;
      });

    })

    // Write video to file
    .pipe(fs.createWriteStream(mainOutput));

    // write the info operation
    fs.writeFile(filepath, startObjectAction, err => {
         response.send(responseJson);
    });
  }

